import { CommonModule } from '@angular/common'
import { Component, computed, inject, Input } from '@angular/core'
import { MatButtonModule } from '@angular/material/button'
import { MatIconModule } from '@angular/material/icon'
import {
  CAT_ACTIVIDADES,
  FlujoRemoto,
  FormularioValues,
  StepActividad,
} from '../../interfaces/step-actividad.interface'
import { ActividadAltaAtmComponent } from '../actividades/actividad-alta-atm/actividad-alta-atm.component'
import { ActividadCargaSolicitudComponent } from '../actividades/actividad-carga-solicitud/actividad-carga-solicitud.component'
import { ActividadInstalacionComponent } from '../actividades/actividad-instalacion/actividad-instalacion.component'
import { ActividadValidacionNegocioComponent } from '../actividades/actividad-validacion-negocio/actividad-validacion-negocio.component'
import { ActividadValidacionOperacionesComponent } from '../actividades/actividad-validacion-operaciones/actividad-validacion-operaciones.component'
import { ActividadValidacionTecnicaComponent } from '../actividades/actividad-validacion-tecnica/actividad-validacion-tecnica.component'
import { ActividadValidacionVisitaComponent } from '../actividades/actividad-validacion-visita/actividad-validacion-visita.component'
import { WizardControllerService } from './wizard-controller.service'

@Component({
  selector: 'app-step-actividades',
  standalone: true,
  imports: [
    CommonModule,
    MatIconModule,
    MatButtonModule,
    ActividadCargaSolicitudComponent,
    ActividadValidacionTecnicaComponent,
    ActividadValidacionVisitaComponent,
    ActividadValidacionOperacionesComponent,
    ActividadValidacionNegocioComponent,
    ActividadInstalacionComponent,
    ActividadAltaAtmComponent,
  ],
  templateUrl: './step-actividades.component.html',
  styleUrls: ['./step-actividades.component.sass'],
})
export class StepActividadesComponent {
  private ctl = inject(WizardControllerService)
  steps = this.ctl.steps

  @Input() inicio = 1
  private _tipoAtm = ''

  @Input() set tipoAtm(value: string) {
    this._tipoAtm = value
    this.ctl.iniciarFlujo(value === 'remoto' ? FlujoRemoto : [])
  }

  @Input() set idSolicitud(value: string) {
    //CREAR LÓGICA CON EL ID DE LA SOLICITUD
    console.log('ID Solicitud recibido en StepActividades:', value)
  }

  trackById = (_: number, s: StepActividad) => s.id
  currentStep = computed(() => this.steps().find((s) => s.activo))

  CAT_ACTIVIDADES = CAT_ACTIVIDADES

  updAvance(id: number, avance: number): void {
    console.log('[STEPPER:AVANCE] id =>', id, 'avance =>', avance)
    this.ctl.actualizarFlujo((currentSteps) =>
      currentSteps.map((step) =>
        step.id === id ? { ...step, progreso: step.progreso + avance } : step
      )
    )
  }

  avanzarStep(stepId: number, forms: FormularioValues[]): void {
    console.log('[STEPPER:AVANZAR] id =>', stepId, 'forms =>', forms)

    const current = this.ctl.steps()
    const exists = current.some((s) => s.id === stepId)
    if (!exists) return

    const nextSteps = current.map((s) =>
      s.id === stepId ? { ...s, formsValues: forms, progreso: 100, activo: false } : s
    )

    this.ctl.actualizarFlujo(() => nextSteps)
    this.ctl.despacharStep(stepId, this._tipoAtm, nextSteps)
  }

  get tipoAtm() {
    return this._tipoAtm
  }

  cambiarStep(id: number): void {
    this.ctl.actualizarFlujo((list) => list.map((step) => ({ ...step, activo: step.id === id })))
  }

  bloquearStep(id: number): void {
    this.ctl.actualizarFlujo((list) =>
      list.map((step) => (step.id === id ? { ...step, bloqueado: true } : step))
    )
  }

  desbloquearStep(id: number): void {
    this.ctl.actualizarFlujo((list) =>
      list.map((step) => (step.id === id ? { ...step, bloqueado: false } : step))
    )
  }

  actualizarStep(id: number, cambios: Partial<StepActividad>): void {
    this.ctl.actualizarFlujo((list) =>
      list.map((step) => (step.id === id ? { ...step, ...cambios } : step))
    )
  }

  resetSteps(): void {
    const inicio = this.inicio
    this.ctl.actualizarFlujo((list) =>
      list.map((s) => ({
        ...s,
        activo: s.id === inicio,
        bloqueado: false,
      }))
    )
  }
  onActivate(id: number) {
    const s = this.steps().find((x) => x.id === id)
    if (!s || s.bloqueado) return
    this.cambiarStep(id)
  }
}
