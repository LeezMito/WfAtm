export type LiteralUnion<T extends string> = T | (string & Record<never, never>)
export type FieldType = 'input' | 'textarea' | 'select' | 'file' | 'checkbox'

export interface SelectOption {
  value: string | number | boolean
  label: string
}

export interface FieldConfig {
  key: string
  tipo: FieldType
  label: string
  value?: unknown
  placeholder?: string
  isRequired?: boolean
  maxLength?: number
  minLength?: number
  maxValue?: number
  minValue?: number
  fileExt?: string[]
  options?: ReadonlyArray<SelectOption>
  disabled?: boolean
}
