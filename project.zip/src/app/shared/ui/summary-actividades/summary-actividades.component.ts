import { Component } from '@angular/core';

@Component({
  selector: 'app-summary-actividades',
  standalone: true,
  imports: [],
  templateUrl: './summary-actividades.component.html',
  styleUrl: './summary-actividades.component.sass'
})
export class SummaryActividadesComponent {

}
